#include "types.h"
#include "user.h"
#include "stat.h"


//normal linear search 
int main (int argc, char *argv[]){

    int val = atoi(argv[1]); //the value we want to search about
    int found = 0;

    int i = 2, j = argc - 1;
    while(i <= j){
        if(atoi(argv[i]) == val || atoi(argv[j]) == val){
            found = 1;
            break;
        }
        else 
            found = 0;
        ++i;
        --j;
    }

    if (found == 1)
        printf(1,"The value %d is found\n", val);
    else
        printf(1,"The value %d is NOT found\n", val);


    exit();
}



    