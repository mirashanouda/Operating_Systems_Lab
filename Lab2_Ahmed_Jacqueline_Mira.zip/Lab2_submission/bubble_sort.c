#include "types.h"
#include "stat.h"
#include "user.h"
int main(int argc,char *argv[])
{
  int  c, d, swap,newarr[argc];


for (c = 1 ; c < argc; c++)
{
newarr[c-1]=atoi(argv[c]);
}


  for (c = 0 ; c < argc-1 ; c++)
  {
    for (d = 0 ; d < argc - c-1 ; d++)
    {
      if (newarr[d] > newarr[d+1]) /* For decreasing order use '<' instead of '>' */
      {
        swap       = newarr[d];
        newarr[d]   = newarr[d+1];
        newarr[d+1] = swap;
}      
}
    }
  


  for (c = 1; c < argc; c++){
     printf(1,"%d\n" ,newarr[c]);
}
  exit();
}