#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"


int main(int argc,char *argv[]){

    if (argc != 2)
    {
        printf(1,"Invalid number of arguments.\n");
        exit();
    }
    int nProc = atoi(argv[1]);

    int id = -1;
    printf(1, "Parent ID = %d\n", getpid());
    for (int i = 0; i < nProc; i+= 1){
        id = fork();
        if (id == 0){ //child process
            setPriority(getpid(), 100-i);
            sumT(i);
            i = nProc; //terminating the child 
        }
        else {
            int k = 0;
            for(int i = 0; i < 100; i++)
                k = k + 1;
        }
        procTable();
    }

    while (wait() != -1){// status is not needed 
        continue; 
    }
    exit();
}